#pragma once

#include <string>
#include <list>

bool get_files_in_path(const std::string &path, std::list<std::string> &filename);


